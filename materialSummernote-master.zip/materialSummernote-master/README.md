## Material-summernote V 0.9.7

A Summernote wysiwyg editor version converted for Materialize
 (Materialize [Official website](http://materializecss.com/))

##### Added features:

*   Following toolbar
*   global restyling


MaterialSummernote is a fork of Summernote wysiwyg editor
 (See the [Original API](http://summernote.org/#/deep-dive))
 Edited by CK

##### There are some extra options

that you can pass to the constructor in materialSummernote:

*   defaultTextColor (used by "color" button to set the default text color)
*   defaultBackColor (used by "color" button to set button's color default color)
*   followingToolbar [default true] (makes the toolbar follow on window scroll)

MaterialSummernote is not just a conversion of Summernote from bootstrap to materialize,
 it also contains some changes

It is provided with scss version of the stylesheet, if you use sass, to change style quickly

In this version, editor's functions that you see on this page are tested; other summernote functions such airmode, still need to be converted;
