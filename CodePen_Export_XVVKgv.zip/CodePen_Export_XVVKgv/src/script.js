        $(function () {
            $('.modal').modal();
            console.log('modal init.');
        });